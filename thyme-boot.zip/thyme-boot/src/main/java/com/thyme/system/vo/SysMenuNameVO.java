package com.thyme.system.vo;

import lombok.Builder;
import lombok.Data;

/**
 * @author cuiyating
 * @date 2020/1/16 16:58
 */
@Data
public class SysMenuNameVO extends SysMenuVO{

    private String menuNames;

    public SysMenuNameVO(){

    }
}
