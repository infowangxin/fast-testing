package com.thyme.system.entity.systeminfo;

import cn.hutool.core.util.NumberUtil;
import lombok.Setter;

/**
 * @author thyme
 * @ClassName MemInfo
 * @Description TODO
 * @Date 2019/12/25 10:32
 */
@Setter
public class MemInfo {

    /**
     * 内存总量
     */
    private double total;

    /**
     * 已用内存
     */
    private double used;

    /**
     * 剩余内存
     */
    private double free;

    /**
     * 使用率
     */

    public double getTotal() {
        return NumberUtil.div(total, (1024 * 1024 * 1024), 2);
    }

    public double getUsed() {
        return NumberUtil.div(used, (1024 * 1024 * 1024), 2);
    }


    public double getFree() {
        return NumberUtil.div(free, (1024 * 1024 * 1024), 2);
    }

    public double getUsage() {
        return NumberUtil.mul(NumberUtil.div(used, total, 4), 100);
    }
}
