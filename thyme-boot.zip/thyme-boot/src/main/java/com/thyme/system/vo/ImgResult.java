package com.thyme.system.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author thyme
 * @ClassName ImgResult
 * @Description TODO
 * @Date 2019/12/16 22:33
 */
@Data
@AllArgsConstructor
public class ImgResult {

    private String img;

    private String uuid;
}
